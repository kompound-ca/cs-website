"use strict";
(() => {
  // src/content/cs2inspects-bridge.ts
  function isTriggerRequest(d) {
    return !!d && typeof d === "object" && d.type === "CS2INSPECTS_TRIGGER_REGEN" && typeof d.selector === "string" && typeof d.requestId === "string";
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (!isTriggerRequest(event.data)) return;
    const { selector, requestId } = event.data;
    const panel = document.querySelector(selector);
    let invoked = false;
    if (panel) {
      const inputs = [...panel.querySelectorAll("input")].filter(
        (i) => i.readOnly
      );
      for (const inp of inputs) {
        let node = inp;
        for (let i = 0; i < 6 && node; i++) {
          const propsKey = Object.keys(node).find(
            (k) => k.startsWith("__reactProps")
          );
          if (propsKey) {
            const props = node[propsKey];
            const handler = props?.onClick;
            if (typeof handler === "function") {
              try {
                handler({
                  preventDefault: () => {
                  },
                  stopPropagation: () => {
                  },
                  currentTarget: node,
                  target: inp,
                  type: "click",
                  nativeEvent: {}
                });
                invoked = true;
              } catch {
              }
            }
          }
          node = node.parentElement;
        }
      }
    }
    window.postMessage(
      { type: "CS2INSPECTS_TRIGGER_DONE", requestId, invoked },
      "*"
    );
  });
})();
