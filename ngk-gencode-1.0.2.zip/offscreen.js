"use strict";
(() => {
  // src/offscreen/index.ts
  chrome.runtime.onMessage.addListener(
    (msg, _sender, sendResponse) => {
      if (!msg || msg.type !== "OFFSCREEN_WRITE_CLIPBOARD" || typeof msg.text !== "string") {
        return false;
      }
      navigator.clipboard.writeText(msg.text).then(
        () => {
          const r = { ok: true };
          sendResponse(r);
        },
        (e) => {
          const r = {
            ok: false,
            error: e instanceof Error ? e.message : String(e)
          };
          sendResponse(r);
        }
      );
      return true;
    }
  );
})();
